var group__global__state =
[
    [ "alertSystemStopped", "group__global__state.html#gaf423f28d52cc69dfecab220b038b5a03", null ],
    [ "currentHumidity", "group__global__state.html#gae38ebdca688c226cb3e0ea11e7050b57", null ],
    [ "currentTemperature", "group__global__state.html#ga29ec8c270db62d59abe6ed3288b3809b", null ],
    [ "lastPirTrigger", "group__global__state.html#gaeaf4c8ed3c35b3d58cf8b84354f03699", null ],
    [ "motionPersistenceCounter", "group__global__state.html#gacfea30a9758440ba970eb57576fc2d56", null ],
    [ "pirTriggered", "group__global__state.html#ga08f21ab73f5c35d00fe7798013d79f43", null ],
    [ "stopButtonPressed", "group__global__state.html#ga7e778ae3df12a943f80592d917cd4f93", null ],
    [ "temperatureDataValid", "group__global__state.html#gad33d98fbd669c099421558760fd79a80", null ]
];