var group__pin__config =
[
    [ "ALERT_LED_PIN", "group__pin__config.html#gac58b6a94aa0ccae5475f28e851202fdc", null ],
    [ "AM2302_PIN", "group__pin__config.html#gad459e41c84e38de975aff099c80c29ef", null ],
    [ "PIR_PIN", "group__pin__config.html#ga386bd5a6168d14ed64af7d5a53d4ce47", null ],
    [ "STATUS_LED_PIN", "group__pin__config.html#ga089a71f836911c71b3f73fdd3b4b890b", null ],
    [ "STOP_BUTTON_PIN", "group__pin__config.html#ga9da436c5bf6a3ce86e3c4a178ca6a862", null ]
];