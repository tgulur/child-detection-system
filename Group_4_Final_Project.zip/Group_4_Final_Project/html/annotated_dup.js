var annotated_dup =
[
    [ "AlertLedData", "struct_alert_led_data.html", "struct_alert_led_data" ],
    [ "MotionData", "struct_motion_data.html", "struct_motion_data" ],
    [ "TemperatureData", "struct_temperature_data.html", "struct_temperature_data" ]
];