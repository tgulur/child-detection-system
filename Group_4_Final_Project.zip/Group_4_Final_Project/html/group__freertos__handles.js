var group__freertos__handles =
[
    [ "alertLedTaskHandle", "group__freertos__handles.html#gaed1d569b081c537c085099ddd7e12f99", null ],
    [ "alertQueue", "group__freertos__handles.html#ga2e8229f0feb0ad116803149f4286f2e8", null ],
    [ "displayTaskHandle", "group__freertos__handles.html#ga6481473160dbb61b2d1cb7eb2372846b", null ],
    [ "motionQueue", "group__freertos__handles.html#ga2665eaa81a8a0b679a03a328d53cdbed", null ],
    [ "motionTaskHandle", "group__freertos__handles.html#ga546f4e5598675ac5413f9431e0058f16", null ],
    [ "temperatureQueue", "group__freertos__handles.html#gac52afd52889baae6a2539dc65e664d32", null ],
    [ "temperatureTaskHandle", "group__freertos__handles.html#ga686eba44f17789a40d2c111fb05e4092", null ]
];