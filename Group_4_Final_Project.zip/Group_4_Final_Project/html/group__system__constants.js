var group__system__constants =
[
    [ "ALERT_STOP_THRESHOLD", "group__system__constants.html#gadf8cb1995af54b6334b287d7daf37032", null ],
    [ "BASE_CRITICAL_BLINK_COUNTER", "group__system__constants.html#ga19526fb68b8a93afd00c9e0cfbf90955", null ],
    [ "BASE_FAST_BLINK_COUNTER", "group__system__constants.html#gacd95e40c02afbdec7bb5b1663b1e2a06", null ],
    [ "BASE_MEDIUM_BLINK_COUNTER", "group__system__constants.html#ga176833662fbdd60cdc4b46f967135d96", null ],
    [ "BASE_SLOW_BLINK_COUNTER", "group__system__constants.html#gaa1c1e9bf55225d129a6c6732dfb92037", null ],
    [ "COMFORTABLE_TEMP", "group__system__constants.html#gab2f7eea740e0d2b9c5aef7d5e34a192f", null ],
    [ "CRITICAL_BLINK_INTERVAL", "group__system__constants.html#gab0c4ae8be678e90e917f649e5cc3eaea", null ],
    [ "CRITICAL_TEMP_THRESHOLD", "group__system__constants.html#gace09a09447510eb5ce1df883585c509e", null ],
    [ "FAST_BLINK_INTERVAL", "group__system__constants.html#ga9309946a66e2ae3c39728484a00cf001", null ],
    [ "HOT_TEMP_THRESHOLD", "group__system__constants.html#gacfd0ab8870613c86729068fd67005cbe", null ],
    [ "MAX_PERSISTENCE_COUNTER", "group__system__constants.html#ga63acc3d8075606bc29b3bf1bb0fd9d6d", null ],
    [ "MEDIUM_BLINK_INTERVAL", "group__system__constants.html#ga11a1b2905a38f4f95dd8c7d2b604ffa0", null ],
    [ "MIN_COUNTER_FOR_ALERT", "group__system__constants.html#gabefa38ddd8fd0ed7948bb065761e8045", null ],
    [ "PIR_DETECTION_WINDOW", "group__system__constants.html#gac5ef1b1acf8ae5e402bd27846ba687eb", null ],
    [ "SLOW_BLINK_INTERVAL", "group__system__constants.html#ga1c65f1e9d3d2e9e39680861eb5c6e78c", null ]
];