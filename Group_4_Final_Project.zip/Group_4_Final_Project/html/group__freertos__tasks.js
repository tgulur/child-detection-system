var group__freertos__tasks =
[
    [ "alertLedTask", "group__freertos__tasks.html#ga1ac58d3a2c462ad5f683ea0f9427e9a9", null ],
    [ "displayTask", "group__freertos__tasks.html#gac55d0909bfe96e544bb1324d9e0be983", null ],
    [ "motionDetectionTask", "group__freertos__tasks.html#ga831f98f925aec6e63bab0a9258eb3acd", null ],
    [ "temperatureTask", "group__freertos__tasks.html#ga96c361e8ae7194173d6843a3b9a2fb73", null ]
];