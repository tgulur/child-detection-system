var struct_temperature_data =
[
    [ "humidity", "struct_temperature_data.html#a805803319e7255e14fa319cc4dffd30a", null ],
    [ "temperature", "struct_temperature_data.html#a1fde0ad41c64b063f6dc28f0d75bd25e", null ],
    [ "timestamp", "struct_temperature_data.html#a0f420ea3a8d576f3902c21990864c420", null ],
    [ "validReading", "struct_temperature_data.html#a92904d3e93024a518ba758a7318553d8", null ]
];