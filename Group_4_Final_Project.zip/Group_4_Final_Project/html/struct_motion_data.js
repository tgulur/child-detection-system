var struct_motion_data =
[
    [ "alertLevel", "struct_motion_data.html#a99057c9c2c1077b906c163322f613c16", null ],
    [ "alertSystemStopped", "struct_motion_data.html#acf8bc0832d4c154126bd4987ea7e154c", null ],
    [ "humidity", "struct_motion_data.html#afa4ac9eb3e147ec1158ccb9a73985e34", null ],
    [ "message", "struct_motion_data.html#affd28b25447bdf3428222bf94b5665f0", null ],
    [ "motionDetected", "struct_motion_data.html#a8bff24643bcc021257257265ede204d1", null ],
    [ "persistenceCounter", "struct_motion_data.html#a197ed3db5b6a31c5acfb3e4060c90826", null ],
    [ "temperature", "struct_motion_data.html#a4f84a65c7b3c8feefdd6ed77a72000e9", null ],
    [ "timestamp", "struct_motion_data.html#a82ff30a07be9265f330416eb0d8cc5b8", null ]
];