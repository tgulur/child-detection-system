var topics =
[
    [ "GPIO Pin Configuration", "group__pin__config.html", "group__pin__config" ],
    [ "Hardware Interface Objects", "group__hardware__objects.html", "group__hardware__objects" ],
    [ "FreeRTOS Task and Queue Handles", "group__freertos__handles.html", "group__freertos__handles" ],
    [ "System Data Structures", "group__data__structures.html", "group__data__structures" ],
    [ "Global System State Variables", "group__global__state.html", "group__global__state" ],
    [ "Hardware Timer Configuration", "group__timer__hardware.html", "group__timer__hardware" ],
    [ "System Configuration Constants", "group__system__constants.html", "group__system__constants" ],
    [ "Hardware Interrupt Service Routines", "group__interrupt__handlers.html", "group__interrupt__handlers" ],
    [ "FreeRTOS Task Implementations", "group__freertos__tasks.html", "group__freertos__tasks" ]
];