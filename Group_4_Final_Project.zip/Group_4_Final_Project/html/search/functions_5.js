var searchData=
[
  ['motiondetectiontask_0',['motionDetectionTask',['../group__freertos__tasks.html#ga831f98f925aec6e63bab0a9258eb3acd',1,'Group_4_Final_Project.ino']]],
  ['motionisr_1',['motionISR',['../group__interrupt__handlers.html#gaeca6547ded353afe67810703b8cb3f51',1,'Group_4_Final_Project.ino']]]
];
