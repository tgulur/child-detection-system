var searchData=
[
  ['freertos_20task_20and_20queue_20handles_0',['FreeRTOS Task and Queue Handles',['../group__freertos__handles.html',1,'']]],
  ['freertos_20task_20implementations_1',['FreeRTOS Task Implementations',['../group__freertos__tasks.html',1,'']]]
];
