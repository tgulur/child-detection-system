var searchData=
[
  ['data_20structures_0',['System Data Structures',['../group__data__structures.html',1,'']]]
];
