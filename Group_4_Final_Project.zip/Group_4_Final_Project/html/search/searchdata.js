var indexSectionsWithContent =
{
  0: "abcdfghilmopqrstv",
  1: "amt",
  2: "g",
  3: "acdglmost",
  4: "abcdfhlmpstv",
  5: "acdfghiopqrstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Modules"
};

