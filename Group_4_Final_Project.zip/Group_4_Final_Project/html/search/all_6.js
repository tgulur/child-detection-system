var searchData=
[
  ['handles_0',['FreeRTOS Task and Queue Handles',['../group__freertos__handles.html',1,'']]],
  ['hardware_20interface_20objects_1',['Hardware Interface Objects',['../group__hardware__objects.html',1,'']]],
  ['hardware_20interrupt_20service_20routines_2',['Hardware Interrupt Service Routines',['../group__interrupt__handlers.html',1,'']]],
  ['hardware_20timer_20configuration_3',['Hardware Timer Configuration',['../group__timer__hardware.html',1,'']]],
  ['hot_5ftemp_5fthreshold_4',['HOT_TEMP_THRESHOLD',['../group__system__constants.html#gacfd0ab8870613c86729068fd67005cbe',1,'Group_4_Final_Project.ino']]],
  ['humidity_5',['humidity',['../struct_motion_data.html#afa4ac9eb3e147ec1158ccb9a73985e34',1,'MotionData::humidity'],['../struct_temperature_data.html#a805803319e7255e14fa319cc4dffd30a',1,'TemperatureData::humidity']]]
];
