var searchData=
[
  ['temperaturedata_0',['TemperatureData',['../struct_temperature_data.html',1,'']]]
];
