var searchData=
[
  ['task_20and_20queue_20handles_0',['FreeRTOS Task and Queue Handles',['../group__freertos__handles.html',1,'']]],
  ['task_20implementations_1',['FreeRTOS Task Implementations',['../group__freertos__tasks.html',1,'']]],
  ['temperature_2',['temperature',['../struct_motion_data.html#a4f84a65c7b3c8feefdd6ed77a72000e9',1,'MotionData::temperature'],['../struct_temperature_data.html#a1fde0ad41c64b063f6dc28f0d75bd25e',1,'TemperatureData::temperature']]],
  ['temperaturedata_3',['TemperatureData',['../struct_temperature_data.html',1,'']]],
  ['temperaturedatavalid_4',['temperatureDataValid',['../group__global__state.html#gad33d98fbd669c099421558760fd79a80',1,'Group_4_Final_Project.ino']]],
  ['temperaturequeue_5',['temperatureQueue',['../group__freertos__handles.html#gac52afd52889baae6a2539dc65e664d32',1,'Group_4_Final_Project.ino']]],
  ['temperaturetask_6',['temperatureTask',['../group__freertos__tasks.html#ga96c361e8ae7194173d6843a3b9a2fb73',1,'Group_4_Final_Project.ino']]],
  ['temperaturetaskhandle_7',['temperatureTaskHandle',['../group__freertos__handles.html#ga686eba44f17789a40d2c111fb05e4092',1,'Group_4_Final_Project.ino']]],
  ['timer_20configuration_8',['Hardware Timer Configuration',['../group__timer__hardware.html',1,'']]],
  ['timer0_9',['timer0',['../group__timer__hardware.html#ga25ee574a82660d392759061e40e6afa6',1,'Group_4_Final_Project.ino']]],
  ['timermux_10',['timerMux',['../group__timer__hardware.html#gadedb0f4641b7b425776dbacb23a96576',1,'Group_4_Final_Project.ino']]],
  ['timestamp_11',['timestamp',['../struct_motion_data.html#a82ff30a07be9265f330416eb0d8cc5b8',1,'MotionData::timestamp'],['../struct_temperature_data.html#a0f420ea3a8d576f3902c21990864c420',1,'TemperatureData::timestamp']]]
];
