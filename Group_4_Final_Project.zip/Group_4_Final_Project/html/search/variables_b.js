var searchData=
[
  ['validreading_0',['validReading',['../struct_temperature_data.html#a92904d3e93024a518ba758a7318553d8',1,'TemperatureData']]]
];
