var searchData=
[
  ['comfortable_5ftemp_0',['COMFORTABLE_TEMP',['../group__system__constants.html#gab2f7eea740e0d2b9c5aef7d5e34a192f',1,'Group_4_Final_Project.ino']]],
  ['counterupdateflag_1',['counterUpdateFlag',['../group__timer__hardware.html#ga8b8179545ba8c8e3b7f0a13629cde9c1',1,'Group_4_Final_Project.ino']]],
  ['critical_5fblink_5finterval_2',['CRITICAL_BLINK_INTERVAL',['../group__system__constants.html#gab0c4ae8be678e90e917f649e5cc3eaea',1,'Group_4_Final_Project.ino']]],
  ['critical_5ftemp_5fthreshold_3',['CRITICAL_TEMP_THRESHOLD',['../group__system__constants.html#gace09a09447510eb5ce1df883585c509e',1,'Group_4_Final_Project.ino']]],
  ['currenthumidity_4',['currentHumidity',['../group__global__state.html#gae38ebdca688c226cb3e0ea11e7050b57',1,'Group_4_Final_Project.ino']]],
  ['currenttemperature_5',['currentTemperature',['../group__global__state.html#ga29ec8c270db62d59abe6ed3288b3809b',1,'Group_4_Final_Project.ino']]]
];
