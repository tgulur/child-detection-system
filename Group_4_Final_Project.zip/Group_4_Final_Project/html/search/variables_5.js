var searchData=
[
  ['hot_5ftemp_5fthreshold_0',['HOT_TEMP_THRESHOLD',['../group__system__constants.html#gacfd0ab8870613c86729068fd67005cbe',1,'Group_4_Final_Project.ino']]],
  ['humidity_1',['humidity',['../struct_motion_data.html#afa4ac9eb3e147ec1158ccb9a73985e34',1,'MotionData::humidity'],['../struct_temperature_data.html#a805803319e7255e14fa319cc4dffd30a',1,'TemperatureData::humidity']]]
];
