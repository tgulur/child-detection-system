var searchData=
[
  ['global_20system_20state_20variables_0',['Global System State Variables',['../group__global__state.html',1,'']]],
  ['gpio_20pin_20configuration_1',['GPIO Pin Configuration',['../group__pin__config.html',1,'']]]
];
