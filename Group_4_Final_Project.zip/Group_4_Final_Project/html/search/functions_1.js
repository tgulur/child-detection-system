var searchData=
[
  ['calculateblinkrate_0',['calculateBlinkRate',['../_group__4___final___project_8ino.html#adfacf54e12018b63bb775a9c265e7560',1,'Group_4_Final_Project.ino']]],
  ['calculatetemperatureadjustedthresholds_1',['calculateTemperatureAdjustedThresholds',['../_group__4___final___project_8ino.html#a77842e16e28d671d1c1b77223c756cee',1,'Group_4_Final_Project.ino']]]
];
