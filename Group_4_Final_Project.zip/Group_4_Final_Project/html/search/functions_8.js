var searchData=
[
  ['temperaturetask_0',['temperatureTask',['../group__freertos__tasks.html#ga96c361e8ae7194173d6843a3b9a2fb73',1,'Group_4_Final_Project.ino']]]
];
