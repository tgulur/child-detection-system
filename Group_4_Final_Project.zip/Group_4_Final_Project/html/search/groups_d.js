var searchData=
[
  ['variables_0',['Global System State Variables',['../group__global__state.html',1,'']]]
];
