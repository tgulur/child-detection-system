var searchData=
[
  ['persistencecounter_0',['persistenceCounter',['../struct_motion_data.html#a197ed3db5b6a31c5acfb3e4060c90826',1,'MotionData']]],
  ['pir_5fdetection_5fwindow_1',['PIR_DETECTION_WINDOW',['../group__system__constants.html#gac5ef1b1acf8ae5e402bd27846ba687eb',1,'Group_4_Final_Project.ino']]],
  ['pirtriggered_2',['pirTriggered',['../group__global__state.html#ga08f21ab73f5c35d00fe7798013d79f43',1,'Group_4_Final_Project.ino']]]
];
