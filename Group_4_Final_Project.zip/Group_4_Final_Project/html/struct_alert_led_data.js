var struct_alert_led_data =
[
    [ "active", "struct_alert_led_data.html#a702585a45ffcc807d816b060db0caea2", null ],
    [ "blinkRate", "struct_alert_led_data.html#af7eeeb8410d48b3a8664f13b6a820006", null ],
    [ "forceUpdate", "struct_alert_led_data.html#a2bb39e121a2f06f9560605192cbd439f", null ]
];