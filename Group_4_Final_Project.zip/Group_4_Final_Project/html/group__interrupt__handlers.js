var group__interrupt__handlers =
[
    [ "motionISR", "group__interrupt__handlers.html#gaeca6547ded353afe67810703b8cb3f51", null ],
    [ "stopButtonISR", "group__interrupt__handlers.html#ga242dc3597af10e794b48b96ee3d2d41c", null ]
];